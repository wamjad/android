package bad.twitterfriendschannel;

import android.os.AsyncTask;

import org.json.JSONArray;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class GitHubCall extends AsyncTask<String, Void, String> {

    @Override
    protected String doInBackground(String[] params) {
        try {
            String response = test();
            JSONArray resp = new JSONArray(response);
            System.out.println(resp.toString());
        }catch(Exception e){
            e.printStackTrace();
        }
        return "Success";
    }

    @Override
    protected void onPostExecute(String message) {
        //process message
    }
    protected String test() throws Exception{
        URL url = new URL("https://api.github.com/users/mralexgray/repos");
        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        try {
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            String response = readStream(in);
            return response;
        }
        catch (Exception e){
            e.printStackTrace();

        }
        finally {
            urlConnection.disconnect();
        }
        return null;

    }
    protected String readStream(InputStream in){
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        StringBuilder sb = new StringBuilder();
        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append((line + "\n"));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        String response = sb.toString();
        return response;
    }
}
